// src/pages/Dashboard.js
import React, { useState, useEffect } from "react";
import './style.css';
import Cookies from "js-cookie";

const Dashboard = () => {
  const [data, setData] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const token = Cookies.get("tokenUser"); 
    fetch("http://localhost:5000", {
      method: "GET", // hoặc POST, PATCH ...
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,  // Gửi token ở đây
      },
      // body: JSON.stringify(data) nếu method là POST, PATCH ...
    })
      .then((res) => res.json())
      .then((json) => {
        if (json.documents) {
          setData(json.documents);
        }
      })
      .catch((err) => console.error("Lỗi khi lấy dữ liệu:", err))
      .finally(() => setLoading(false));
  }, []);
  
  if (loading) return <div className="loading">Đang tải dữ liệu...</div>;

  return (
    <div className="dashboard-container">
      <div className="card-list">
        {data.map((item) => (
          <div
            key={item._id}
            className="card"
            onClick={() => setSelectedItem(item)}
          >
            <h3>{item.title}</h3>
            <p>{item.description.substring(0, 80)}...</p>
          </div>
        ))}
      </div>

      {selectedItem && (
        <div className="details-card">
          <h2>{selectedItem.title}</h2>
          <p><strong>Mô tả:</strong> {selectedItem.description}</p>
          <p><strong>Trạng thái:</strong> {selectedItem.status}</p>
          <p><strong>Ngày tạo:</strong> {new Date(selectedItem.createdAt).toLocaleString()}</p>
          <img
            src={selectedItem.thumbnail}
            alt={selectedItem.title}
            className="thumbnail"
          />
          <button onClick={() => setSelectedItem(null)} className="close-button">
            Đóng
          </button>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
